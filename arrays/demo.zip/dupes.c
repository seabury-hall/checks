/*
Write a program that finds and prints any duplicate elements in an array of integers.
Requirements:
 - Use a loop within a loop to compare each element with every other element.
*/

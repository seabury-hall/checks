/*
Count the number of even and odd numbers in an integer array.
  - Print the number of evens
  - Print the number of odds
*/
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main(void)
{
    int n = 10;
    int numbers[n];
    srand(time(0));

    for (int i = 0; i < n; i++)
    {
        numbers[i] = rand() % n;
    }

    int evens = 0;
    int odds = 0;

    for(int i = 0; i < n; i++)
    {
      printf("%i\n", numbers[i]);

      if(numbers[i] % 2 == 0)
      {
        evens++;
      }
      else
      {
        odds++;
      }

    }

    printf("Even Count: %i\nOdd Count: %i\n", evens, odds);

}


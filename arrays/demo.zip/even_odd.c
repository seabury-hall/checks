/*
Count the number of even and odd numbers in an integer array.
  - Print the number of evens
  - Print the number of odds
*/



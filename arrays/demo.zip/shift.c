/*
Write a program to shift the elements of an integer array to the left by one position.
The first element should move to the end. You should use a function called shift, and maybe also
a function called print array.

Requirements:
  - Create an integer array with at least 5 elements.
  - Print the original array
  - After shifting, the first element goes to the last position.
  - Print the array again
*/

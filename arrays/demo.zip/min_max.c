/*
Calculate the minimum and maximum values in int array
  - Print the minimum value
  - Print he maximum value
*/


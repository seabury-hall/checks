/*
Calculate the minimum and maximum values in int array
  - Print the minimum value
  - Print he maximum value
*/
#include <cs50.h>
#include <stdio.h>

int main(void)
{

  int length = 5;
  int spookyArray[] = {9, 2, 51, 4, 50};

  int max = spookyArray[0];
  int min = spookyArray[0];

  for(int i = 0; i < length; i++)
  {
    if(spookyArray[i] > max)
    {
      max = spookyArray[i];
    }

    if(spookyArray[i] < min)
    {
      min = spookyArray[i];
    }

  }

  printf("Maximum number is: %i\n", max);
  printf("Minimum Number is: %i\n", min);

}

/*
Write a program that adds corresponding elements of two arrays and stores the result in a third array.

Requirements:
Create three arrays of the same size, where the third array holds the sums of the first two arrays.
  - Print the first array
  - print the second array
  - print the resulting array
*/

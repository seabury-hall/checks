/*
Write a program that adds corresponding elements of two arrays and stores the result in a third array.

Requirements:
Create three arrays of the same size, where the third array holds the sums of the first two arrays.
  - Print the first array
  - print the second array
  - print the resulting array
*/

/*
Write a program that reverses the elements in an integer array.
  - print the original values in the array
  - modify the array
  - print the values again
*/


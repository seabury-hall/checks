/*
Write a program that reverses the elements in an integer array.
  - print the original values in the array
  - modify the array
  - print the values again
*/
